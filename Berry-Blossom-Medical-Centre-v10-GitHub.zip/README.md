# Berry Blossom Medical Centre v10

Fresh rebuild focused on polish, usability and crisp scalable artwork.

Included:
- three 1920×1080 vector theme artworks
- strawberry / autumn-leaf / snowflake physics particles
- custom SVG icons, avatars, frames and badges
- mandatory application gate with 70% threshold
- department-specific + general medical MCQs
- admin application review
- Hospital Live: staff, shifts, rota, patient board, requests, EMS, emergency code drills
- training
- DOB + birthday frame
- rewards, avatars, frames and name flares
- Roblox presence / Maple Hospital / Cherry Blossom hooks
- admin-only global theme control
- GitHub Pages workflow, PWA files, Supabase and Cloudflare scaffolding

Demo: admin/admin and rosie/rosie.

The frontend runs immediately in local demo mode. Real multi-user deployment requires connecting the included Supabase/Cloudflare pieces.
